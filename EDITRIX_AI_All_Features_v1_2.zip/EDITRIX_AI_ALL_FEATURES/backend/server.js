import express from "express";
import cors from "cors";
import multer from "multer";
import { spawn } from "node:child_process";
import { randomUUID } from "node:crypto";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const workDir = path.join(__dirname, "work");
fs.mkdirSync(workDir, { recursive: true });

const app = express();
app.use(cors());
app.use("/exports", express.static(workDir, { dotfiles: "deny", index: false }));
const upload = multer({
  dest: workDir,
  limits: { fileSize: 500 * 1024 * 1024, files: 6 },
  fileFilter: (_req, file, cb) => {
    const allowed = file.fieldname === "videos" ? file.mimetype.startsWith("video/")
      : file.fieldname === "audio" ? (file.mimetype.startsWith("audio/") || file.mimetype === "application/octet-stream")
      : false;
    cb(allowed ? null : new Error("Unsupported upload type."), allowed);
  }
});

app.get("/api/health", (_req, res) => res.json({ ok: true, service: "EDITRIX multi-clip renderer" }));

function runFFmpeg(args) {
  return new Promise((resolve, reject) => {
    const proc = spawn("ffmpeg", args);
    let stderr = "";
    proc.stderr.on("data", chunk => {
      stderr += chunk.toString();
      if (stderr.length > 16000) stderr = stderr.slice(-16000);
    });
    proc.on("error", err => reject(new Error(`Could not start FFmpeg: ${err.message}. Install FFmpeg and ensure it is on PATH.`)));
    proc.on("close", code => code === 0 ? resolve() : reject(new Error(`FFmpeg exited with code ${code}: ${stderr.slice(-2500)}`)));
  });
}

app.post("/api/project-export", upload.fields([{ name: "videos", maxCount: 5 }, { name: "audio", maxCount: 1 }]), async (req, res) => {
  const videos = req.files?.videos || [];
  const audios = req.files?.audio || [];
  const cleanupInputs = [...videos, ...audios].map(f => f.path);
  const cleanup = () => cleanupInputs.forEach(p => fs.unlink(p, () => {}));

  if (!videos.length) {
    cleanup();
    return res.status(400).json({ error: "Upload at least one video clip." });
  }

  const resolution = req.body.resolution === "4k" ? 3840 : 1920;
  const transition = req.body.transition === "fade" ? "fade" : "cut";
  const caption = String(req.body.caption || "").trim().slice(0, 120);
  const start = Number(req.body.start || 0);
  const end = req.body.end === "" || req.body.end == null ? null : Number(req.body.end);

  if (!Number.isFinite(start) || start < 0 || (end !== null && (!Number.isFinite(end) || end <= start))) {
    cleanup();
    return res.status(400).json({ error: "Invalid trim values for the first clip." });
  }

  const id = randomUUID();
  const outputName = `${id}.mp4`;
  const output = path.join(workDir, outputName);

  try {
    const args = ["-hide_banner", "-y"];
    videos.forEach((f, i) => {
      if (i === 0 && start > 0) args.push("-ss", String(start));
      args.push("-i", f.path);
    });
    const audioIndex = videos.length;
    if (audios[0]) args.push("-i", audios[0].path);

    const filters = [];
    const labels = [];
    videos.forEach((_f, i) => {
      const label = `v${i}`;
      let trim = "";
      if (i === 0 && end !== null) trim = `,trim=duration=${Math.max(0.1, end - start)},setpts=PTS-STARTPTS`;
      else trim = ",setpts=PTS-STARTPTS";
      filters.push(`[${i}:v]scale=${resolution}:${resolution}:force_original_aspect_ratio=decrease,pad=${resolution}:${resolution}:(ow-iw)/2:(oh-ih)/2,setsar=1,fps=30,format=yuv420p${trim}[${label}]`);
      labels.push(`[${label}]`);
    });

    if (videos.length === 1) {
      filters.push(`${labels[0]}null[vout]`);
    } else if (transition === "fade") {
      // Sequential short crossfades; duration and offset are estimated from each input's duration by FFmpeg.
      // xfade needs known offsets, so this MVP uses a deterministic 0.5s fade between normalized clips.
      let current = labels[0];
      let accumulatedOffset = null;
      const probeDurations = await Promise.all(videos.map(f => probeDuration(f.path)));
      const firstDuration = Math.max(0.6, (end !== null ? Math.min(probeDurations[0], end - start) : probeDurations[0]) - start);
      accumulatedOffset = firstDuration - 0.5;
      for (let i = 1; i < videos.length; i++) {
        const outLabel = `xf${i}`;
        filters.push(`${current}${labels[i]}xfade=transition=fade:duration=0.5:offset=${Math.max(0.1, accumulatedOffset)}[${outLabel}]`);
        current = `[${outLabel}]`;
        accumulatedOffset += Math.max(0.1, probeDurations[i] - 0.5);
      }
      filters.push(`${current}null[vout]`);
    } else {
      filters.push(`${labels.join("")}concat=n=${videos.length}:v=1:a=0[vout]`);
    }

    if (audios[0]) {
      filters.push(`[${audioIndex}:a]aresample=44100,volume=0.85,atrim=duration=3600,asetpts=PTS-STARTPTS[aout]`);
    }

    if (caption) {
      // Escape characters for FFmpeg drawtext filter value.
      const escaped = caption.replace(/\\/g, "\\\\").replace(/:/g, "\\:").replace(/'/g, "\\'").replace(/%/g, "\\%").replace(/\n/g, " ");
      filters.push(`[vout]drawtext=text='${escaped}':fontcolor=white:fontsize=h/18:borderw=3:bordercolor=black:x=(w-text_w)/2:y=h-text_h-80[vfinal]`);
    }

    args.push("-filter_complex", filters.join(";"));
    args.push("-map", caption ? "[vfinal]" : "[vout]");
    if (audios[0]) args.push("-map", "[aout]");
    else args.push("-map", "0:a?");
    args.push("-c:v", "libx264", "-preset", "veryfast", "-crf", "20", "-pix_fmt", "yuv420p");
    if (audios[0]) args.push("-c:a", "aac", "-b:a", "192k", "-shortest");
    else args.push("-c:a", "aac", "-b:a", "192k");
    args.push("-movflags", "+faststart", output);

    await runFFmpeg(args);
    cleanup();
    res.json({ ok: true, url: `/exports/${outputName}`, resolution: resolution === 3840 ? "4K" : "1080p", clips: videos.length });
  } catch (err) {
    cleanup();
    fs.unlink(output, () => {});
    console.error(err?.message || err);
    res.status(500).json({ error: err?.message || "Video rendering failed." });
  }
});

function probeDuration(file) {
  return new Promise(resolve => {
    const p = spawn("ffprobe", ["-v", "error", "-show_entries", "format=duration", "-of", "default=noprint_wrappers=1:nokey=1", file]);
    let out = "";
    p.stdout.on("data", d => out += d.toString());
    p.on("error", () => resolve(1));
    p.on("close", code => resolve(code === 0 && Number.isFinite(Number(out)) ? Number(out) : 1));
  });
}

app.use((err, _req, res, _next) => {
  console.error(err?.message || err);
  if (err instanceof multer.MulterError && err.code === "LIMIT_FILE_SIZE") return res.status(413).json({ error: "Each uploaded file must be smaller than 500 MB." });
  res.status(400).json({ error: err?.message || "Upload failed." });
});

const port = process.env.PORT || 4000;
app.listen(port, "0.0.0.0", () => console.log(`EDITRIX AI renderer listening on port ${port}`));
