import React, { useState } from "react";
import {
  ActivityIndicator, Alert, SafeAreaView, ScrollView, StatusBar,
  StyleSheet, Text, TextInput, TouchableOpacity, View
} from "react-native";
import * as ImagePicker from "expo-image-picker";
import * as FileSystem from "expo-file-system/legacy";
import * as Sharing from "expo-sharing";
import { VideoView, useVideoPlayer } from "expo-video";

const API_BASE_URL = "http://YOUR_COMPUTER_LAN_IP:4000";

type Asset = { uri: string; name: string; durationMs: number; type: "video" | "audio" };
type ExportSettings = { resolution: "1080" | "4k"; transition: "cut" | "fade" };

function Preview({ uri }: { uri: string | null }) {
  const player = useVideoPlayer(uri, p => { p.loop = true; });
  if (!uri) return <View style={styles.empty}><Text style={styles.emptyIcon}>▶</Text><Text style={styles.muted}>Add clips to preview your project</Text></View>;
  return <VideoView player={player} style={styles.preview} nativeControls contentFit="contain" />;
}

export default function App() {
  const [clips, setClips] = useState<Asset[]>([]);
  const [audio, setAudio] = useState<Asset | null>(null);
  const [caption, setCaption] = useState("");
  const [start, setStart] = useState("0");
  const [end, setEnd] = useState("");
  const [resolution, setResolution] = useState<"1080" | "4k">("1080");
  const [transition, setTransition] = useState<"cut" | "fade">("cut");
  const [busy, setBusy] = useState(false);
  const [status, setStatus] = useState("");
  const [downloadUrl, setDownloadUrl] = useState("");

  async function pickVideos() {
    const p = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (!p.granted) return Alert.alert("Permission needed", "Allow access to select videos.");
    const r = await ImagePicker.launchImageLibraryAsync({ mediaTypes: ["videos"], allowsMultipleSelection: true, selectionLimit: 5, quality: 1 });
    if (r.canceled) return;
    const newClips = r.assets.map((a, i) => ({
      uri: a.uri, name: a.fileName || `clip-${clips.length + i + 1}.mp4`,
      durationMs: a.duration || 0, type: "video" as const
    }));
    setClips(old => [...old, ...newClips].slice(0, 5));
    setEnd("");
    setDownloadUrl("");
  }

  async function pickAudio() {
    const p = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (!p.granted) return Alert.alert("Permission needed", "Allow access to select audio.");
    const r = await ImagePicker.launchImageLibraryAsync({ mediaTypes: ["audio"], allowsEditing: false });
    if (r.canceled || !r.assets[0]) return;
    const a = r.assets[0];
    setAudio({ uri: a.uri, name: a.fileName || "music-track", durationMs: a.duration || 0, type: "audio" });
    setDownloadUrl("");
  }

  function moveClip(index: number, direction: -1 | 1) {
    setClips(old => {
      const next = [...old], target = index + direction;
      if (target < 0 || target >= next.length) return old;
      [next[index], next[target]] = [next[target], next[index]];
      return next;
    });
    setDownloadUrl("");
  }

  function removeClip(index: number) {
    setClips(old => old.filter((_, i) => i !== index));
    setDownloadUrl("");
  }

  async function exportProject() {
    if (!clips.length) return Alert.alert("Add video clips", "Choose at least one video clip first.");
    if (clips.length > 5) return Alert.alert("Clip limit", "This version supports up to five video clips.");
    setBusy(true); setStatus("Uploading project media..."); setDownloadUrl("");
    try {
      const form = new FormData();
      clips.forEach((c, i) => form.append("videos", {
        uri: c.uri, name: c.name.toLowerCase().endsWith(".mp4") ? c.name : `clip-${i + 1}.mp4`, type: "video/mp4"
      } as any));
      if (audio) form.append("audio", { uri: audio.uri, name: audio.name.toLowerCase().endsWith(".mp3") ? audio.name : "music.mp3", type: "audio/mpeg" } as any);
      form.append("caption", caption);
      form.append("resolution", resolution);
      form.append("transition", transition);
      form.append("start", start || "0");
      form.append("end", end || "");
      setStatus("Rendering your video...");
      const response = await fetch(`${API_BASE_URL}/api/project-export`, { method: "POST", body: form });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "Export failed");
      setDownloadUrl(`${API_BASE_URL}${data.url}`);
      setStatus("Export complete!");
    } catch (e: any) {
      setStatus("");
      Alert.alert("Export failed", e?.message || "Check your backend URL and server.");
    } finally { setBusy(false); }
  }

  async function shareExport() {
    if (!downloadUrl) return;
    try {
      const file = await FileSystem.downloadAsync(downloadUrl, `${FileSystem.cacheDirectory}editrix-${Date.now()}.mp4`);
      if (await Sharing.isAvailableAsync()) await Sharing.shareAsync(file.uri, { mimeType: "video/mp4", dialogTitle: "Save or share EDITRIX project" });
      else Alert.alert("Downloaded", `Temporary file: ${file.uri}`);
    } catch (e: any) { Alert.alert("Download failed", e?.message || "Try again."); }
  }

  return (
    <SafeAreaView style={styles.safe}>
      <StatusBar barStyle="dark-content" backgroundColor="#F4F8FF" />
      <ScrollView contentContainerStyle={styles.container}>
        <View style={styles.header}>
          <View style={styles.logo}><Text style={styles.logoText}>E</Text></View>
          <View style={{ flex: 1 }}><Text style={styles.brand}>EDITRIX <Text style={styles.blue}>AI</Text></Text><Text style={styles.muted}>Multi-track creative studio</Text></View>
          <Text style={styles.pill}>PRO EDITOR</Text>
        </View>

        <View style={styles.hero}>
          <Text style={styles.eyebrow}>YOUR CREATIVE TIMELINE</Text>
          <Text style={styles.heroTitle}>Edit every{"\n"}moment.</Text>
          <Text style={styles.heroSub}>Arrange clips, add music, captions and transitions.</Text>
        </View>

        <View style={styles.previewCard}>
          <Text style={styles.section}>Preview</Text>
          <Preview uri={clips[0]?.uri || null} />
          <Text style={styles.tip}>Preview shows the first clip. The complete sequence is rendered when you export.</Text>
        </View>

        <View style={styles.sectionRow}>
          <Text style={styles.section}>Video timeline</Text>
          <Text style={styles.count}>{clips.length}/5 CLIPS</Text>
        </View>
        <TouchableOpacity style={styles.primaryButton} onPress={pickVideos}><Text style={styles.primaryText}>＋  Add video clips</Text></TouchableOpacity>
        {clips.map((clip, i) => (
          <View key={`${clip.uri}-${i}`} style={styles.clipRow}>
            <View style={styles.clipNumber}><Text style={styles.clipNumberText}>{i + 1}</Text></View>
            <View style={{ flex: 1 }}><Text style={styles.clipName} numberOfLines={1}>{clip.name}</Text><Text style={styles.clipMeta}>{clip.durationMs ? `${(clip.durationMs / 1000).toFixed(1)} sec` : "Duration detected during export"}</Text></View>
            <TouchableOpacity style={styles.smallAction} onPress={() => moveClip(i, -1)}><Text style={styles.actionText}>↑</Text></TouchableOpacity>
            <TouchableOpacity style={styles.smallAction} onPress={() => moveClip(i, 1)}><Text style={styles.actionText}>↓</Text></TouchableOpacity>
            <TouchableOpacity style={styles.deleteAction} onPress={() => removeClip(i)}><Text style={styles.deleteText}>×</Text></TouchableOpacity>
          </View>
        ))}
        {!clips.length && <Text style={styles.emptyHint}>Your video clips will appear here. Use the arrows to reorder them.</Text>}

        <View style={styles.panel}>
          <Text style={styles.section}>Audio track</Text>
          <TouchableOpacity style={styles.secondaryButton} onPress={pickAudio}><Text style={styles.secondaryText}>♫  {audio ? "Change music / audio" : "Add music or audio"}</Text></TouchableOpacity>
          <Text style={styles.tip}>{audio ? `Selected: ${audio.name}` : "Optional: add one music or audio file to your project."}</Text>
        </View>

        <View style={styles.panel}>
          <Text style={styles.section}>Text overlay / title</Text>
          <TextInput style={styles.input} value={caption} onChangeText={setCaption} placeholder="Type a title or caption to show on the video..." placeholderTextColor="#91A0B3" maxLength={120} />
          <Text style={styles.tip}>The text is burned into the exported video using FFmpeg's drawtext filter.</Text>
        </View>

        <View style={styles.panel}>
          <Text style={styles.section}>Transitions</Text>
          <View style={styles.choiceRow}>
            <TouchableOpacity style={[styles.choice, transition === "cut" && styles.choiceActive]} onPress={() => setTransition("cut")}><Text style={[styles.choiceText, transition === "cut" && styles.choiceTextActive]}>Hard cut</Text></TouchableOpacity>
            <TouchableOpacity style={[styles.choice, transition === "fade" && styles.choiceActive]} onPress={() => setTransition("fade")}><Text style={[styles.choiceText, transition === "fade" && styles.choiceTextActive]}>Fade between clips</Text></TouchableOpacity>
          </View>
          <Text style={styles.tip}>Fade uses a short crossfade between adjacent clips. Hard cut joins clips directly.</Text>
        </View>

        <View style={styles.panel}>
          <Text style={styles.section}>Export settings</Text>
          <View style={styles.choiceRow}>
            <TouchableOpacity style={[styles.choice, resolution === "1080" && styles.choiceActive]} onPress={() => setResolution("1080")}><Text style={[styles.choiceText, resolution === "1080" && styles.choiceTextActive]}>1080p HD</Text></TouchableOpacity>
            <TouchableOpacity style={[styles.choice, resolution === "4k" && styles.choiceActive]} onPress={() => setResolution("4k")}><Text style={[styles.choiceText, resolution === "4k" && styles.choiceTextActive]}>4K UHD</Text></TouchableOpacity>
          </View>
          <Text style={styles.tip}>4K output can upscale smaller clips but cannot restore missing image detail.</Text>
          <Text style={styles.fieldLabel}>Optional trim start (seconds, first clip only)</Text>
          <TextInput style={styles.input} value={start} onChangeText={setStart} keyboardType="decimal-pad" placeholder="0" />
          <Text style={styles.fieldLabel}>Optional trim end (seconds, first clip only; blank = full clip)</Text>
          <TextInput style={styles.input} value={end} onChangeText={setEnd} keyboardType="decimal-pad" placeholder="Full clip" />
        </View>

        <TouchableOpacity style={[styles.exportButton, busy && { opacity: 0.65 }]} disabled={busy} onPress={exportProject}>
          {busy ? <ActivityIndicator color="white" /> : <Text style={styles.exportSymbol}>⇧</Text>}
          <Text style={styles.exportLabel}>{busy ? "Rendering project..." : "Export complete video"}</Text>
        </TouchableOpacity>
        {!!status && <Text style={styles.status}>{status}</Text>}
        {!!downloadUrl && <TouchableOpacity style={styles.shareButton} onPress={shareExport}><Text style={styles.shareLabel}>↓  Download / Share MP4</Text></TouchableOpacity>}

        <View style={styles.info}><Text style={styles.infoTitle}>Included in this build</Text><Text style={styles.infoText}>Up to 5 ordered video clips • optional audio track • text overlay • hard cuts or crossfades • 1080p / 4K MP4 export.</Text></View>
        <Text style={styles.footer}>EDITRIX AI · Create without limits</Text>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: "#F4F8FF" }, container: { padding: 18, paddingBottom: 42 },
  header: { flexDirection: "row", alignItems: "center", gap: 11, marginBottom: 20 },
  logo: { width: 45, height: 45, borderRadius: 14, backgroundColor: "#1769E0", alignItems: "center", justifyContent: "center" },
  logoText: { color: "white", fontWeight: "900", fontSize: 26 }, brand: { color: "#102B4C", fontSize: 20, fontWeight: "900", letterSpacing: 1 },
  blue: { color: "#1769E0" }, muted: { color: "#8394A9", fontSize: 11, marginTop: 3 },
  pill: { color: "#1769E0", backgroundColor: "#E5F0FF", paddingHorizontal: 10, paddingVertical: 7, borderRadius: 18, fontSize: 9, fontWeight: "900" },
  hero: { backgroundColor: "#E5F0FF", padding: 21, borderRadius: 22, marginBottom: 17 },
  eyebrow: { color: "#1769E0", fontSize: 10, fontWeight: "900", letterSpacing: 1.5, marginBottom: 8 },
  heroTitle: { color: "#102B4C", fontSize: 31, fontWeight: "900", lineHeight: 35 }, heroSub: { color: "#637A96", fontSize: 12, marginTop: 8 },
  previewCard: { backgroundColor: "white", borderRadius: 18, borderWidth: 1, borderColor: "#E1EAF5", padding: 14, marginBottom: 18 },
  section: { color: "#173452", fontWeight: "900", fontSize: 15, marginBottom: 11 },
  preview: { width: "100%", height: 190, borderRadius: 12, backgroundColor: "#0D1B2A" },
  empty: { height: 165, backgroundColor: "#F1F6FD", borderRadius: 12, alignItems: "center", justifyContent: "center" },
  emptyIcon: { color: "#1769E0", fontSize: 30, marginBottom: 7 }, tip: { color: "#8798AC", fontSize: 10, lineHeight: 15, marginTop: 8 },
  sectionRow: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", marginBottom: 9 },
  count: { color: "#1769E0", fontWeight: "900", fontSize: 10 },
  primaryButton: { backgroundColor: "#1769E0", borderRadius: 13, padding: 14, alignItems: "center", marginBottom: 10 },
  primaryText: { color: "white", fontWeight: "900", fontSize: 13 },
  clipRow: { flexDirection: "row", alignItems: "center", backgroundColor: "white", borderWidth: 1, borderColor: "#E2EAF4", borderRadius: 13, padding: 9, gap: 7, marginBottom: 7 },
  clipNumber: { width: 27, height: 27, borderRadius: 8, backgroundColor: "#E5F0FF", alignItems: "center", justifyContent: "center" },
  clipNumberText: { color: "#1769E0", fontWeight: "900", fontSize: 11 },
  clipName: { color: "#294764", fontWeight: "800", fontSize: 11 }, clipMeta: { color: "#92A1B2", fontSize: 9, marginTop: 3 },
  smallAction: { width: 27, height: 27, borderRadius: 8, backgroundColor: "#EDF4FF", alignItems: "center", justifyContent: "center" },
  actionText: { color: "#1769E0", fontWeight: "900", fontSize: 14 },
  deleteAction: { width: 27, height: 27, borderRadius: 8, backgroundColor: "#FFF0F1", alignItems: "center", justifyContent: "center" },
  deleteText: { color: "#D34B59", fontSize: 19, fontWeight: "700" },
  emptyHint: { color: "#8A9BAF", fontSize: 11, marginBottom: 15 },
  panel: { backgroundColor: "white", borderRadius: 17, borderWidth: 1, borderColor: "#E1EAF5", padding: 14, marginTop: 12 },
  secondaryButton: { backgroundColor: "#EDF5FF", borderRadius: 11, padding: 12, alignItems: "center" },
  secondaryText: { color: "#1769E0", fontWeight: "900", fontSize: 12 },
  input: { borderWidth: 1, borderColor: "#DCE7F5", borderRadius: 11, padding: 12, color: "#173452", backgroundColor: "#FBFDFF", fontSize: 12 },
  fieldLabel: { color: "#61758D", fontSize: 10, fontWeight: "800", marginTop: 12, marginBottom: 6 },
  choiceRow: { flexDirection: "row", gap: 9 },
  choice: { flex: 1, borderWidth: 1, borderColor: "#DDE7F3", borderRadius: 11, padding: 12, alignItems: "center", backgroundColor: "#FBFDFF" },
  choiceActive: { borderColor: "#1769E0", backgroundColor: "#EAF3FF" },
  choiceText: { color: "#49627D", fontWeight: "800", fontSize: 11 }, choiceTextActive: { color: "#1769E0" },
  exportButton: { backgroundColor: "#1769E0", borderRadius: 14, padding: 16, flexDirection: "row", gap: 9, justifyContent: "center", alignItems: "center", marginTop: 18 },
  exportSymbol: { color: "white", fontSize: 20 }, exportLabel: { color: "white", fontWeight: "900", fontSize: 14 },
  status: { color: "#1769E0", textAlign: "center", fontSize: 11, marginTop: 10 },
  shareButton: { backgroundColor: "#E5F0FF", borderRadius: 12, padding: 14, marginTop: 10 },
  shareLabel: { color: "#1769E0", fontWeight: "900", textAlign: "center", fontSize: 12 },
  info: { backgroundColor: "#EAF3FF", borderRadius: 14, padding: 14, marginTop: 18 },
  infoTitle: { color: "#1769E0", fontWeight: "900", marginBottom: 5 }, infoText: { color: "#637A96", fontSize: 11, lineHeight: 17 },
  footer: { textAlign: "center", color: "#9AA9BA", fontSize: 10, marginTop: 22 }
});
